package com.example.myapplication;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.DatabaseReseHelper;

import java.util.ArrayList;
import java.util.List;

public class DAO {
    private SQLiteDatabase database;
    private DatabaseReseHelper dbHelper;

    public DAO(Context context) {
        dbHelper = new DatabaseReseHelper(context);
        database = dbHelper.getWritableDatabase();
    }

    // --- User Operations ---
    public long addUser(String name, String email) {
        ContentValues values = new ContentValues();
        values.put(DatabaseReseHelper.COLUMN_USER_NAME, name);
        values.put(DatabaseReseHelper.COLUMN_USER_EMAIL, email);
        return database.insert(DatabaseReseHelper.TABLE_USERS, null, values);
    }

    public Cursor getUser(long userId) {
        return database.query(DatabaseReseHelper.TABLE_USERS,
                null, DatabaseReseHelper.COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null);
    }

    public List<Cursor> getAllUsers() {
        List<Cursor> users = new ArrayList<>();
        Cursor cursor = database.query(DatabaseReseHelper.TABLE_USERS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                users.add(cursor);
            } while (cursor.moveToNext());
        }
        return users;
    }

    // --- Reservation Operations ---
    public long addReservation(long userId, String date, String status) {
        ContentValues values = new ContentValues();
        values.put(DatabaseReseHelper.COLUMN_RESERVATION_USER_ID, userId);
        values.put(DatabaseReseHelper.COLUMN_RESERVATION_DATE, date);
        values.put(DatabaseReseHelper.COLUMN_RESERVATION_STATUS, status);
        return database.insert(DatabaseReseHelper.TABLE_RESERVATIONS, null, values);
    }

    public Cursor getReservation(long reservationId) {
        return database.query(DatabaseReseHelper.TABLE_RESERVATIONS,
                null, DatabaseReseHelper.COLUMN_RESERVATION_ID + "=?",
                new String[]{String.valueOf(reservationId)}, null, null, null);
    }

    public List<Cursor> getAllReservations() {
        List<Cursor> reservations = new ArrayList<>();
        Cursor cursor = database.query(DatabaseReseHelper.TABLE_RESERVATIONS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                reservations.add(cursor);
            } while (cursor.moveToNext());
        }
        return reservations;
    }

    // --- Payment Operations ---
    public long addPayment(long userId, double amount, String date) {
        ContentValues values = new ContentValues();
        values.put(DatabaseReseHelper.COLUMN_PAYMENT_USER_ID, userId);
        values.put(DatabaseReseHelper.COLUMN_PAYMENT_AMOUNT, amount);
        values.put(DatabaseReseHelper.COLUMN_PAYMENT_DATE, date);
        return database.insert(DatabaseReseHelper.TABLE_PAYMENTS, null, values);
    }

    public Cursor getPayment(long paymentId) {
        return database.query(DatabaseReseHelper.TABLE_PAYMENTS,
                null, DatabaseReseHelper.COLUMN_PAYMENT_ID + "=?",
                new String[]{String.valueOf(paymentId)}, null, null, null);
    }

    public List<Cursor> getAllPayments() {
        List<Cursor> payments = new ArrayList<>();
        Cursor cursor = database.query(DatabaseReseHelper.TABLE_PAYMENTS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                payments.add(cursor);
            } while (cursor.moveToNext());
        }
        return payments;
    }
}
