package com.example.myapplication;

import android.provider.BaseColumns;

public final class DatabaseContract {

    private DatabaseContract() {}

    public static class PaymentEntry implements BaseColumns {
        public static final String TABLE_NAME = "payments";
        public static final String COLUMN_PAYMENT_ID = "paymentId";
        public static final String COLUMN_AMOUNT = "amount";
    }
}
