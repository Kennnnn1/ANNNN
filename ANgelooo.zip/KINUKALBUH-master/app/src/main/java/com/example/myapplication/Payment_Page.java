package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Payment_Page extends AppCompatActivity {

    private TextView lastname, firstname, contactnumber, email, courts, date, time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_payment_page);

        lastname = findViewById(R.id.txtLastname);
        firstname = findViewById(R.id.txtFirstname);
        contactnumber = findViewById(R.id.txtContactnum);
        email = findViewById(R.id.txtEmail);
        courts = findViewById(R.id.txtCourts);
        date = findViewById(R.id.txtDate);
        time = findViewById(R.id.txtTime);

        // Retrieve data from the intent
        Intent intent = getIntent();
        lastname.setText(intent.getStringExtra("lastname"));
        firstname.setText(intent.getStringExtra("firstname"));
        contactnumber.setText(intent.getStringExtra("contactnumber"));
        email.setText(intent.getStringExtra("email"));
        courts.setText(intent.getStringExtra("courts"));
        date.setText(intent.getStringExtra("date"));
        time.setText(intent.getStringExtra("time"));
    }
}
